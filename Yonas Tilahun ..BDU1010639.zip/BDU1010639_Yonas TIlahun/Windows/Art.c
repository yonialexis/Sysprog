
#include <stdio.h>


int main(){
char x;
printf("Welcome User, This will Clean your pc of Junk files \n");
printf("Thus increase pc performance \n");
printf("Enter A for code1, B for code2, C for code3 \n");
x=getchar();
if (x='A'){

    printf("This Code 1");
    printf("The following command deletes all temporary, prefetch and recent files");
    system("code4.bat");
    //
}

else if (x='B'){

printf("This Code 2");
printf("This deletes all temporary files with out pop up  dialoge box");
    system("code3.bat");
}

else if (x='C'){

printf("This Code 3");
printf("This deletes all temporary files with out pop up  dialoge box");
    system("code1.bat");

}

printf("All Is Done You can exit now");

return 0;
}
