#!/bin/bash 
#This script will automatically delete temporary files
rm -rf /tmp/* 
rm -rf/var/tmp/*
fsck -A
Exit